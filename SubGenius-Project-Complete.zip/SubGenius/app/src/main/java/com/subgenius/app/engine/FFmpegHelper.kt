package com.subgenius.app.engine

import android.content.Context
import android.net.Uri
import com.arthenica.ffmpegkit.FFmpegKit
import com.arthenica.ffmpegkit.FFprobeKit
import com.arthenica.ffmpegkit.ReturnCode
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import java.io.File
import java.util.Locale
import kotlin.coroutines.resume

object FFmpegHelper {

    /** null = لم نجرّب بعد، true = الترميز العتادي يعمل، false = فشل سابقاً فنتجاوزه */
    @Volatile private var hwEncoderOk: Boolean? = null

    /** ينسخ الفيديو من content:// إلى ملف حقيقي يفهمه FFmpeg */
    fun copyUriToCache(context: Context, uri: Uri): File? = try {
        val out = File(context.cacheDir, "input_${System.currentTimeMillis()}.mp4")
        val copied = context.contentResolver.openInputStream(uri)?.use { input ->
            out.outputStream().use { input.copyTo(it) }
            true
        } ?: false
        if (copied) out else null
    } catch (e: Exception) { null }

    private data class Info(val durationMs: Long, val bitrate: Long)

    private fun probe(file: File): Info = try {
        val m = FFprobeKit.getMediaInformation(file.absolutePath).mediaInformation
        Info(
            ((m?.duration?.toDoubleOrNull() ?: 0.0) * 1000).toLong(),
            m?.bitrate?.toLongOrNull() ?: 0L
        )
    } catch (e: Exception) { Info(0L, 0L) }

    /** تشغيل FFmpeg مع نسبة تقدم حقيقية */
    private suspend fun run(args: List<String>, durationMs: Long, onProgress: (Int) -> Unit): Boolean =
        suspendCancellableCoroutine { cont ->
            val session = FFmpegKit.executeWithArgumentsAsync(
                args.toTypedArray(),
                { s -> if (cont.isActive) cont.resume(ReturnCode.isSuccess(s.returnCode)) },
                { },
                { st ->
                    if (durationMs > 0) {
                        val pct = ((st.time.toLong() * 100) / durationMs).toInt().coerceIn(0, 99)
                        onProgress(pct)
                    }
                }
            )
            cont.invokeOnCancellation { FFmpegKit.cancel(session.sessionId) }
        }

    /**
     * ترميز الفيديو: يجرّب h264_mediacodec (عتادي، أسرع بكثير عادةً) ثم يرجع إلى mpeg4 (برمجي).
     * filters: بدائل الفلتر بالترتيب (الأفضل أولاً). null = بلا فلتر.
     */
    private suspend fun encode(
        video: File, out: File, filters: List<String?>,
        hwBitrate: Int, swQ: Int, durationMs: Long, onProgress: (Int) -> Unit
    ): Boolean {
        fun args(vf: String?, hw: Boolean): List<String> {
            val a = mutableListOf("-i", video.absolutePath)
            if (vf != null) a += listOf("-vf", vf)
            a += if (hw) listOf("-c:v", "h264_mediacodec", "-b:v", hwBitrate.toString())
            else listOf("-c:v", "mpeg4", "-q:v", swQ.toString())
            a += listOf("-pix_fmt", "yuv420p", "-c:a", "aac", "-b:a", "128k", "-y", out.absolutePath)
            return a
        }
        for (vf in filters) {
            var triedHw = false
            if (hwEncoderOk != false) {
                triedHw = true
                if (run(args(vf, true), durationMs, onProgress)) { hwEncoderOk = true; return true }
            }
            if (run(args(vf, false), durationMs, onProgress)) {
                if (triedHw && hwEncoderOk == null) hwEncoderOk = false   // العتادي فشل والبرمجي نجح بنفس الفلتر
                return true
            }
        }
        return false
    }

    /** يستخرج الصوت كـ PCM خام 16kHz mono (بدون ترويسة WAV) */
    suspend fun extractAudio(context: Context, videoFile: File, onProgress: (Int) -> Unit = {}): Result<File> {
        val info = withContext(Dispatchers.IO) { probe(videoFile) }
        val out = File(context.cacheDir, "audio_${System.currentTimeMillis()}.pcm")
        val ok = run(
            listOf("-i", videoFile.absolutePath, "-vn", "-ac", "1", "-ar", "16000", "-f", "s16le", "-y", out.absolutePath),
            info.durationMs, onProgress
        )
        return if (ok) { onProgress(100); Result.success(out) } else Result.failure(Exception("فشل استخراج الصوت (هل في الفيديو صوت؟)"))
    }

    suspend fun compressVideo(context: Context, videoFile: File, level: CompressionLevel, onProgress: (Int) -> Unit = {}): Result<File> {
        if (level == CompressionLevel.NONE) return Result.success(videoFile)
        val info = withContext(Dispatchers.IO) { probe(videoFile) }
        val out = File(context.cacheDir, "compressed_${System.currentTimeMillis()}.mp4")
        val scale = if (level.maxWidth > 0) "scale='min(${level.maxWidth},iw)':-2" else null
        // لا نطلب معدل بت أعلى من 70% من الأصلي حتى لا يكبر الملف
        val hwRate = if (info.bitrate > 0) minOf(level.hwBitrate.toLong(), info.bitrate * 7 / 10).toInt() else level.hwBitrate
        val ok = encode(videoFile, out, listOf(scale), hwRate.coerceAtLeast(500_000), level.q, info.durationMs, onProgress)
        return if (ok) { onProgress(100); Result.success(out) } else Result.failure(Exception("فشل الضغط"))
    }

    suspend fun burnSubtitles(context: Context, videoFile: File, assFile: File, onProgress: (Int) -> Unit = {}): Result<File> {
        val info = withContext(Dispatchers.IO) { probe(videoFile) }
        val fonts = withContext(Dispatchers.IO) { prepareFontsDir(context) }
        val out = File(context.cacheDir, "burned_${System.currentTimeMillis()}.mp4")
        val base = "ass=filename=${esc(assFile.absolutePath)}:fontsdir=${esc(fonts.absolutePath)}"
        // نحافظ على معدل بت قريب من الأصلي (بين 1.5 و12 ميغابت)
        val hwRate = (if (info.bitrate > 0) info.bitrate else 5_000_000L).coerceIn(1_500_000L, 12_000_000L).toInt()
        val ok = encode(videoFile, out, listOf("$base:shaping=complex", base), hwRate, 3, info.durationMs, onProgress)
        return if (ok) { onProgress(100); Result.success(out) } else Result.failure(Exception("فشل حرق الترجمة"))
    }


    // ------------------------------------------------------------------
    // الخطوط
    // ------------------------------------------------------------------

    private val rtlLangs = setOf("ar", "fa", "ur")

    /**
     * اسم الخط المناسب للغة: نستعمل خط النظام إن وُجد، وإلا الخط الاحتياطي المضمّن (DejaVu Sans)
     * حتى لا تظهر مربعات بدل الحروف على أي هاتف.
     */
    suspend fun subtitleFontFor(context: Context, lang: String): String = withContext(Dispatchers.IO) {
        val dir = prepareFontsDir(context)
        val l = lang.lowercase()
        when {
            l in rtlLangs && File(dir, "NotoNaskhArabic-Regular.ttf").exists() -> "Noto Naskh Arabic"
            l in rtlLangs && File(dir, "NotoNaskhArabicUI-Regular.ttf").exists() -> "Noto Naskh Arabic UI"
            l == "zh" && File(dir, "NotoSansCJK-Regular.ttc").exists() -> "Noto Sans CJK SC"
            l == "ja" && File(dir, "NotoSansCJK-Regular.ttc").exists() -> "Noto Sans CJK JP"
            l !in rtlLangs && l != "zh" && l != "ja" && File(dir, "Roboto-Regular.ttf").exists() -> "Roboto"
            else -> "DejaVu Sans"
        }
    }

    // ------------------------------------------------------------------
    // الدبلجة
    // ------------------------------------------------------------------

    suspend fun durationMs(file: File): Long = withContext(Dispatchers.IO) { probe(file).durationMs }

    private fun hasAudioStream(file: File): Boolean = try {
        FFprobeKit.getMediaInformation(file.absolutePath).mediaInformation
            ?.streams?.any { it.type == "audio" } ?: false
    } catch (e: Exception) { false }

    /** يحوّل أي ملف صوت (WAV من TTS) إلى PCM خام mono، مع تسريع اختياري بدون تغيير طبقة الصوت */
    suspend fun toPcm(input: File, out: File, tempo: Double, sampleRate: Int): Boolean {
        val a = mutableListOf("-i", input.absolutePath, "-vn")
        if (tempo > 1.01) a += listOf("-filter:a", String.format(Locale.US, "atempo=%.3f", tempo))
        a += listOf("-ac", "1", "-ar", sampleRate.toString(), "-f", "s16le", "-y", out.absolutePath)
        return run(a, 0L) { }
    }

    /**
     * يدمج مسار الدبلجة (PCM خام s16le mono) مع الفيديو: الصورة تُنسخ كما هي بلا إعادة ترميز،
     * والصوت الأصلي (إن وُجد) يُخفض إلى originalVolume ويُمزج مع الدبلجة.
     */
    suspend fun mixDubbedAudio(
        context: Context, video: File, dubPcm: File, sampleRate: Int,
        originalVolume: Float, onProgress: (Int) -> Unit = {}
    ): Result<File> {
        val info = withContext(Dispatchers.IO) { probe(video) }
        val keepOriginal = withContext(Dispatchers.IO) { hasAudioStream(video) } && originalVolume > 0.01f
        val out = File(context.cacheDir, "dubbed_${System.currentTimeMillis()}.mp4")
        val args = mutableListOf(
            "-i", video.absolutePath,
            "-f", "s16le", "-ar", sampleRate.toString(), "-ac", "1", "-i", dubPcm.absolutePath
        )
        if (keepOriginal) {
            val vol = String.format(Locale.US, "%.2f", originalVolume.coerceIn(0f, 1f))
            args += listOf(
                "-filter_complex",
                "[0:a:0]volume=$vol[bg];[bg][1:a]amix=inputs=2:duration=first:dropout_transition=0,volume=2[a]",
                "-map", "0:v:0", "-map", "[a]"
            )
        } else {
            args += listOf("-map", "0:v:0", "-map", "1:a")
        }
        args += listOf("-c:v", "copy", "-c:a", "aac", "-b:a", "160k", "-shortest", "-y", out.absolutePath)
        val ok = run(args, info.durationMs, onProgress)
        return if (ok) { onProgress(100); Result.success(out) } else Result.failure(Exception("فشل دمج الصوت المدبلج"))
    }

    private fun esc(path: String): String =
        path.replace("\\", "/").replace(":", "\\:").replace("'", "\\'").replace(",", "\\,")

    /** مجلد خطوط: من assets/fonts إن وُجد، وإلا ننسخ خطوط النظام المتوفرة */
    private fun prepareFontsDir(context: Context): File {
        val dir = File(context.cacheDir, "fonts").apply { mkdirs() }
        try {
            context.assets.list("fonts")?.forEach { name ->
                val dst = File(dir, name)
                if (!dst.exists()) context.assets.open("fonts/$name").use { i -> dst.outputStream().use { i.copyTo(it) } }
            }
        } catch (_: Exception) {}
        listOf(
            "NotoNaskhArabic-Regular.ttf", "NotoNaskhArabicUI-Regular.ttf",
            "NotoSansArabic-Regular.ttf", "Roboto-Regular.ttf", "NotoSansCJK-Regular.ttc"
        ).forEach { n ->
            val src = File("/system/fonts", n); val dst = File(dir, n)
            if (src.exists() && !dst.exists()) runCatching { src.copyTo(dst) }
        }
        return dir
    }
}

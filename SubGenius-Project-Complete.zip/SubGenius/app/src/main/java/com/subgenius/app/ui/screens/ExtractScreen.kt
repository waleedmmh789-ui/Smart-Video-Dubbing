package com.subgenius.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.subgenius.app.engine.FFmpegHelper
import com.subgenius.app.engine.SpeechToText
import com.subgenius.app.engine.VoskModelDownloader
import com.subgenius.app.ui.AppViewModel
import com.subgenius.app.ui.components.TopBar
import com.subgenius.app.ui.theme.BgDark
import com.subgenius.app.ui.theme.ErrRed
import com.subgenius.app.ui.theme.Primary
import com.subgenius.app.ui.theme.Secondary
import com.subgenius.app.ui.theme.TextGray
import com.subgenius.app.ui.theme.TextWhite
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ExtractScreen(appViewModel: AppViewModel, onBack: () -> Unit, onDone: () -> Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val state by appViewModel.state.collectAsState()
    var working by remember { mutableStateOf(false) }
    var progress by remember { mutableIntStateOf(0) }
    var stage by remember { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }

    Column(Modifier.fillMaxSize().background(BgDark).padding(horizontal = 20.dp).verticalScroll(rememberScrollState())) {
        TopBar("استخراج النص", onBack)
        Spacer(Modifier.height(8.dp))
        Text("لغة الكلام في الفيديو:", color = TextGray, fontSize = 12.sp)
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            VoskModelDownloader.models.forEach { m ->
                FilterChip(
                    selected = state.sourceLang == m.lang,
                    onClick = { appViewModel.setSourceLang(m.lang) },
                    label = { Text(m.label) },
                    enabled = !working
                )
            }
        }
        Spacer(Modifier.height(16.dp))

        if (!working && state.originalSegments.isEmpty()) {
            Button(
                onClick = {
                    scope.launch {
                        error = null
                        val file = state.videoFile ?: run { error = "لا يوجد فيديو"; return@launch }
                        val modelPath = VoskModelDownloader.getModelPath(context, state.sourceLang)
                            ?: run { error = "نموذج هذه اللغة غير مُنزَّل. نزّله من «تنزيل النماذج»."; return@launch }
                        working = true; progress = 0
                        val audio = FFmpegHelper.extractAudio(context, file) { progress = it / 2; stage = "استخراج الصوت" }
                            .getOrElse { error = it.message; working = false; return@launch }
                        val r = SpeechToText.transcribe(audio, modelPath) { progress = 50 + it / 2; stage = "التعرف على الكلام" }
                        audio.delete(); working = false
                        r.onSuccess { if (it.isEmpty()) error = "لم يُكتشف أي كلام" else appViewModel.setOriginalSegments(it) }
                            .onFailure { error = it.message }
                    }
                },
                modifier = Modifier.fillMaxWidth().height(64.dp),
                shape = RoundedCornerShape(16.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Primary)
            ) { Text("بدء الاستخراج", fontSize = 16.sp) }
        }
        if (working) {
            LinearProgressIndicator(progress = { progress / 100f }, modifier = Modifier.fillMaxWidth(), color = Primary)
            Text("$stage ($progress%)", color = TextGray, fontSize = 14.sp)
        }
        error?.let { Text(it, color = ErrRed, fontSize = 14.sp) }

        if (state.originalSegments.isNotEmpty()) {
            Text("عدد المقاطع: ${state.originalSegments.size}", color = TextWhite)
            Spacer(Modifier.height(8.dp))
            state.originalSegments.forEach { Text(it.text, color = TextWhite, fontSize = 14.sp, modifier = Modifier.padding(vertical = 2.dp)) }
            Spacer(Modifier.height(16.dp))
            Button(
                onClick = onDone, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(12.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Secondary)
            ) { Text("متابعة إلى الترجمة") }
            TextButton(onClick = { appViewModel.clearSegments() }, modifier = Modifier.fillMaxWidth()) { Text("إعادة الاستخراج") }
        }
        Spacer(Modifier.height(32.dp))
    }
}

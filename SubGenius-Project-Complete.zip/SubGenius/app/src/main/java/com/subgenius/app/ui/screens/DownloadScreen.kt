package com.subgenius.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.subgenius.app.engine.VoskModelDownloader
import com.subgenius.app.ui.components.TopBar
import com.subgenius.app.ui.theme.BgDark
import com.subgenius.app.ui.theme.Secondary
import com.subgenius.app.ui.theme.SurfaceDark
import com.subgenius.app.ui.theme.TextGray
import com.subgenius.app.ui.theme.TextWhite
import kotlinx.coroutines.launch

@Composable
fun DownloadScreen(onBack: () -> Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val status = remember {
        mutableStateMapOf<String, String>().apply {
            VoskModelDownloader.models.forEach {
                put(it.lang, if (VoskModelDownloader.getModelPath(context, it.lang) != null) "مُنزَّل ✅" else "غير مُنزَّل")
            }
        }
    }
    var working by remember { mutableStateOf(false) }

    Column(Modifier.fillMaxSize().background(BgDark).padding(horizontal = 20.dp).verticalScroll(rememberScrollState())) {
        TopBar("تنزيل النماذج", onBack)
        Spacer(Modifier.height(16.dp))
        VoskModelDownloader.models.forEach { m ->
            Card(Modifier.fillMaxWidth().padding(bottom = 12.dp), shape = RoundedCornerShape(16.dp), colors = CardDefaults.cardColors(containerColor = SurfaceDark)) {
                Column(Modifier.padding(16.dp)) {
                    Text("نموذج التعرف على الكلام — ${m.label}", color = TextWhite, fontSize = 16.sp)
                    Text("${m.size}، يعمل بدون إنترنت بعد التنزيل", color = TextGray, fontSize = 12.sp)
                    Spacer(Modifier.height(8.dp))
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text(status[m.lang] ?: "", color = Secondary, fontSize = 12.sp)
                        Button(
                            onClick = {
                                scope.launch {
                                    working = true
                                    val r = VoskModelDownloader.downloadAndUnzip(context, m.lang) { status[m.lang] = "جارٍ: $it%" }
                                    working = false
                                    r.onSuccess { status[m.lang] = "مُنزَّل ✅" }
                                        .onFailure { status[m.lang] = "فشل: ${it.message}" }
                                }
                            },
                            enabled = !working
                        ) { Text("تنزيل") }
                    }
                }
            }
        }
        Text("ملاحظة: نماذج الترجمة (ML Kit) تُنزَّل تلقائياً عند أول ترجمة وتحتاج إنترنت.", color = TextGray, fontSize = 12.sp)
    }
}

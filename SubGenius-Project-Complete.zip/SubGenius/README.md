# عبقري الترجمة والدبلجة (SubGenius)

تطبيق أندرويد (Kotlin + Jetpack Compose) يعمل على الجهاز: استخراج الكلام من الفيديو → ترجمته → **دبلجته بصوت** و/أو حرق الترجمة على الفيديو → حفظه في المعرض.

- minSdk 26 (أندرويد 8) — targetSdk 35 — معمار arm64-v8a
- اسم الحزمة الحالي: `com.subgenius.app` (غيّره بـ `bash scripts/rename_package.sh com.اسمك.subgenius`)

## خط العمل
1. اختيار فيديو ← (اختياري) ضغطه
2. استخراج النص (Vosk، دون إنترنت بعد تنزيل النموذج)
3. الترجمة (ML Kit، نموذج كل لغة يُنزَّل أول مرة)
4. **الدبلجة**: صوت النظام (TTS) يُوضع في توقيت الكلام الأصلي، مع خفض صوت الفيديو الأصلي، والصورة تُنسخ بلا إعادة ترميز
5. حرق الترجمة (اختياري) والحفظ في `Movies/SubGenius`

> الدبلجة تحتاج صوت اللغة الهدف مثبّتاً في إعدادات «تحويل النص إلى كلام» بالهاتف (يوجد زر لتثبيته داخل الشاشة).

## البناء على GitHub (APK + AAB)
1. ارفع المجلد كاملاً إلى مستودع GitHub (فرع `main`).
2. تبويب **Actions ← Build SubGenius ← Run workflow**.
3. حمّل من **Artifacts → SubGenius-builds**: `SubGenius-debug.apk` و`SubGenius-release.apk` و`SubGenius-release.aab`.
4. لإصدار على صفحة Releases: ادفع وسماً مثل `v1.1.0`.

### التوقيع
- **بدون Secrets**: يولّد الـ workflow مفتاحاً مؤقتاً، فتحصل على APK وAAB موقّعين للتثبيت المباشر. لا ترفعهما إلى Google Play.
- **للنشر**: أنشئ مفتاحاً ثابتاً مرة واحدة واحفظه في مكان آمن:
  ```bash
  keytool -genkeypair -v -keystore release.keystore -alias subgenius -keyalg RSA -keysize 2048 -validity 10000
  base64 -w0 release.keystore   # انسخ الناتج
  ```
  ثم أضف في GitHub (Settings ← Secrets and variables ← Actions): `KEYSTORE_BASE64` و`KEYSTORE_PASSWORD` و`KEY_ALIAS` و`KEY_PASSWORD`.
  **لا تضيّع هذا المفتاح**: بدونه لا يمكنك تحديث التطبيق على Google Play (إلا عبر Play App Signing).

### البناء محلياً
افتح المجلد في Android Studio (Ladybug أو أحدث). لا يوجد `gradlew` في الحزمة؛ يُنشئه Android Studio تلقائياً (أو شغّل `gradle wrapper --gradle-version 8.9`).

## قبل النشر في Google Play
1. غيّر اسم الحزمة (انظر أعلاه) قبل أول رفع، فلا يمكن تغييره لاحقاً.
2. ضع بريدك في `PRIVACY_POLICY.md` و`docs/index.html`، ثم فعّل **GitHub Pages** (Settings ← Pages ← مجلد `/docs`) واستعمل الرابط كـ «رابط سياسة الخصوصية».
3. صفحات 16KB: الـ workflow يفحص المكتبات ويطبع النتيجة (خطوة Check 16KB). أي سطر `FAIL` يعني مكتبة لا تقبلها Google Play.
4. FFmpeg يعمل على arm64 فقط (كل الهواتف الحديثة). هواتف 32-bit القديمة غير مدعومة.
5. النموذج العربي (MGB2) حجمه ~320MB ويحتاج ذاكرة؛ قد يتعثر على الهواتف الضعيفة.
6. الروابط في `VoskModelDownloader.kt` تحقق منها من https://alphacephei.com/vosk/models إن ظهر خطأ HTTP 404.
7. الخط العربي: يُستعمل خط النظام، والخط الاحتياطي المضمّن `DejaVuSans.ttf` (ترخيص حر) في `assets/fonts`. لخط تفضّله ضع ملف .ttf هناك.
8. تطبيق مجاني: لا فوترة ولا إعلانات.

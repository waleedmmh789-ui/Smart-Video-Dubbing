# R8 متوقف حالياً؛ هذه القواعد احتياطية إن فعّلته لاحقاً
-keep class com.sun.jna.** { *; }
-keep class org.vosk.** { *; }
-keep class com.arthenica.** { *; }
-dontwarn java.awt.**
-dontwarn com.sun.jna.**

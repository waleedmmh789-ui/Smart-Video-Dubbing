package com.subgenius.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.subgenius.app.engine.FFmpegHelper
import com.subgenius.app.engine.SpeechToText
import com.subgenius.app.engine.VoskModelDownloader
import com.subgenius.app.engine.WhisperModelDownloader
import com.subgenius.app.engine.WhisperSpeech
import com.subgenius.app.ui.AppViewModel
import com.subgenius.app.ui.components.TopBar
import com.subgenius.app.ui.theme.BgDark
import com.subgenius.app.ui.theme.ErrRed
import com.subgenius.app.ui.theme.Primary
import com.subgenius.app.ui.theme.Secondary
import com.subgenius.app.ui.theme.TextGray
import com.subgenius.app.ui.theme.TextWhite
import kotlinx.coroutines.launch

private enum class SttEngine { WHISPER, VOSK }

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ExtractScreen(appViewModel: AppViewModel, onBack: () -> Unit, onDone: () -> Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val state by appViewModel.state.collectAsState()
    var engine by remember { mutableStateOf(SttEngine.WHISPER) }
    var direct by remember { mutableStateOf(false) }
    var working by remember { mutableStateOf(false) }
    var progress by remember { mutableIntStateOf(0) }
    var stage by remember { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }
    val hScroll = rememberScrollState()

    val voskLangs = VoskModelDownloader.models.map { it.lang to it.label }
    val langs = if (engine == SttEngine.WHISPER) WhisperSpeech.languages else voskLangs

    Column(Modifier.fillMaxSize().background(BgDark).padding(horizontal = 20.dp).verticalScroll(rememberScrollState())) {
        TopBar("استخراج النص", onBack)
        Spacer(Modifier.height(8.dp))

        Text("محرك التعرف على الكلام:", color = TextGray, fontSize = 12.sp)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilterChip(
                selected = engine == SttEngine.WHISPER,
                onClick = { engine = SttEngine.WHISPER },
                label = { Text("Whisper — أدق (اللهجات)") }, enabled = !working
            )
            FilterChip(
                selected = engine == SttEngine.VOSK,
                onClick = {
                    engine = SttEngine.VOSK
                    if (voskLangs.none { it.first == state.audioLang }) appViewModel.setAudioLang("ar")
                },
                label = { Text("Vosk — أسرع (فصحى)") }, enabled = !working
            )
        }
        Spacer(Modifier.height(12.dp))

        Text("لغة الكلام في الفيديو:", color = TextGray, fontSize = 12.sp)
        Row(Modifier.horizontalScroll(hScroll), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            langs.forEach { (code, label) ->
                FilterChip(
                    selected = state.audioLang == code,
                    onClick = { appViewModel.setAudioLang(code) },
                    label = { Text(label) }, enabled = !working
                )
            }
        }

        if (engine == SttEngine.WHISPER && state.audioLang != "en") {
            Spacer(Modifier.height(12.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("ترجمة مباشرة إلى الإنجليزية", color = TextWhite, fontSize = 14.sp)
                    Text(
                        "أدق للهجات: يترجم من الصوت مباشرة، ثم يمكنك ترجمة الإنجليزية إلى أي لغة أخرى.",
                        color = TextGray, fontSize = 11.sp
                    )
                }
                Switch(checked = direct, onCheckedChange = { direct = it }, enabled = !working)
            }
        }
        Spacer(Modifier.height(16.dp))

        if (!working && state.originalSegments.isEmpty()) {
            Button(
                onClick = {
                    scope.launch {
                        error = null
                        val file = state.videoFile ?: run { error = "لا يوجد فيديو"; return@launch }
                        val lang = state.audioLang
                        val useDirect = engine == SttEngine.WHISPER && direct && lang != "en"
                        val modelPath = if (engine == SttEngine.WHISPER)
                            WhisperModelDownloader.bestModelPath(context)
                        else VoskModelDownloader.getModelPath(context, lang)
                        if (modelPath == null) {
                            error = "نموذج هذا المحرك غير مُنزَّل. نزّله من «تنزيل النماذج»."
                            return@launch
                        }
                        working = true; progress = 0
                        val audio = FFmpegHelper.extractAudio(context, file) { progress = it / 10; stage = "استخراج الصوت" }
                            .getOrElse { error = it.message; working = false; return@launch }
                        val r = if (engine == SttEngine.WHISPER) {
                            WhisperSpeech.transcribe(context, audio, modelPath, lang, useDirect) {
                                progress = 10 + it * 9 / 10; stage = "التعرف على الكلام (Whisper)"
                            }
                        } else {
                            SpeechToText.transcribe(audio, modelPath) {
                                progress = 10 + it * 9 / 10; stage = "التعرف على الكلام (Vosk)"
                            }
                        }
                        audio.delete(); working = false
                        r.onSuccess {
                            if (it.isEmpty()) error = "لم يُكتشف أي كلام"
                            else appViewModel.setOriginalSegments(it, if (useDirect) "en" else null)
                        }.onFailure { error = it.message }
                    }
                },
                modifier = Modifier.fillMaxWidth().height(64.dp),
                shape = RoundedCornerShape(16.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Primary)
            ) { Text("بدء الاستخراج", fontSize = 16.sp) }
        }
        if (working) {
            LinearProgressIndicator(progress = { progress / 100f }, modifier = Modifier.fillMaxWidth(), color = Primary)
            Text("$stage ($progress%)", color = TextGray, fontSize = 14.sp)
            if (engine == SttEngine.WHISPER) {
                Text("Whisper أبطأ من Vosk، وقد يستغرق عدة دقائق للفيديوهات الطويلة.", color = TextGray, fontSize = 11.sp)
            }
        }
        error?.let { Text(it, color = ErrRed, fontSize = 14.sp) }

        if (state.originalSegments.isNotEmpty()) {
            Text("عدد المقاطع: ${state.originalSegments.size} • لغة النص: ${state.sourceLang}", color = TextWhite)
            Spacer(Modifier.height(8.dp))
            state.originalSegments.forEach { Text(it.text, color = TextWhite, fontSize = 14.sp, modifier = Modifier.padding(vertical = 2.dp)) }
            Spacer(Modifier.height(16.dp))
            Button(
                onClick = onDone, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(12.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Secondary)
            ) { Text("متابعة إلى الترجمة") }
            TextButton(onClick = { appViewModel.clearSegments() }, modifier = Modifier.fillMaxWidth()) { Text("إعادة الاستخراج") }
        }
        Spacer(Modifier.height(32.dp))
    }
}

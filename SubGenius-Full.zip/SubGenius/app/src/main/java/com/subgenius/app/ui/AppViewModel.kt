package com.subgenius.app.ui

import android.app.Application
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.subgenius.app.engine.CompressionLevel
import com.subgenius.app.engine.FFmpegHelper
import com.subgenius.app.engine.SpeechSegment
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import java.io.File

data class ProjectState(
    val videoUri: String? = null,
    /** نسخة محلية من الفيديو (تُحدَّث بعد الضغط) */
    val videoFile: File? = null,
    val loading: Boolean = false,
    val compressionLevel: CompressionLevel = CompressionLevel.NONE,
    val originalSegments: List<SpeechSegment> = emptyList(),
    val translatedSegments: List<SpeechSegment> = emptyList(),
    /** لغة الكلام في الفيديو */
    val audioLang: String = "ar",
    /** لغة النص المستخرج (تختلف عن audioLang عند الترجمة المباشرة للإنجليزية) */
    val sourceLang: String = "ar",
    val targetLang: String = "en"
)

class AppViewModel(app: Application) : AndroidViewModel(app) {
    private val _state = MutableStateFlow(ProjectState())
    val state: StateFlow<ProjectState> = _state.asStateFlow()

    /** يبدأ مشروعاً جديداً وينسخ الفيديو من content:// إلى الكاش فوراً */
    fun setVideo(uri: String) {
        val old = _state.value
        old.videoFile?.let { runCatching { it.delete() } }
        _state.value = ProjectState(
            videoUri = uri, loading = true,
            audioLang = old.audioLang, sourceLang = old.audioLang, targetLang = old.targetLang
        )
        viewModelScope.launch(Dispatchers.IO) {
            val f = FFmpegHelper.copyUriToCache(getApplication(), Uri.parse(uri))
            _state.update { if (it.videoUri == uri) it.copy(videoFile = f, loading = false) else it }
        }
    }

    fun setVideoFile(file: File, level: CompressionLevel) {
        _state.value.videoFile?.let { if (it != file) runCatching { it.delete() } }
        _state.update { it.copy(videoFile = file, compressionLevel = level) }
    }

    fun setSourceLang(lang: String) {
        _state.update { it.copy(sourceLang = lang, originalSegments = emptyList(), translatedSegments = emptyList()) }
    }

    fun setAudioLang(lang: String) {
        _state.update {
            it.copy(audioLang = lang, sourceLang = lang, originalSegments = emptyList(), translatedSegments = emptyList())
        }
    }

    /** textLang: لغة النص الناتج (null = نفس لغة الكلام) */
    fun setOriginalSegments(segments: List<SpeechSegment>, textLang: String? = null) {
        _state.update {
            it.copy(originalSegments = segments, translatedSegments = emptyList(), sourceLang = textLang ?: it.audioLang)
        }
    }

    fun clearSegments() {
        _state.update { it.copy(originalSegments = emptyList(), translatedSegments = emptyList()) }
    }

    fun setTranslatedSegments(segments: List<SpeechSegment>, source: String, target: String) {
        _state.update { it.copy(translatedSegments = segments, sourceLang = source, targetLang = target) }
    }
}

package com.subgenius.app.engine

import android.content.Context
import android.os.Bundle
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import java.io.Closeable
import java.io.File
import java.io.RandomAccessFile
import java.util.Locale
import kotlin.coroutines.coroutineContext
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException

/** صوت اللغة الهدف غير مثبّت في محرك تحويل النص إلى كلام بالهاتف */
class TtsLanguageMissingException(val lang: String) :
    Exception("صوت اللغة ($lang) غير مثبّت على الهاتف. ثبّته من إعدادات «تحويل النص إلى كلام».")

/**
 * الدبلجة: النص المترجم → صوت (TTS النظام) → وضع كل مقطع في وقته على مسار PCM → دمجه مع الفيديو.
 * كل المعالجة على الجهاز، ولا يُرفع أي شيء.
 */
object DubbingProcessor {
    const val SAMPLE_RATE = 24000
    private const val MAX_SPEEDUP = 1.7          // أكثر من هذا يصبح الكلام غير مفهوم
    private const val MAX_WORDS_PER_PART = 16
    private const val MAX_PART_MS = 8000L
    private const val MAX_GAP_MS = 500L

    /** يجمع المقاطع القصيرة (7 كلمات) في جمل أطول ليخرج الصوت طبيعياً وأسرع في التوليد */
    fun mergeForDubbing(segments: List<SpeechSegment>): List<SpeechSegment> {
        val out = mutableListOf<SpeechSegment>()
        var cur: SpeechSegment? = null
        var words = 0
        for (s in segments.sortedBy { it.startMs }) {
            val text = s.text.trim()
            if (text.isEmpty()) continue
            val w = text.split(Regex("\\s+")).size
            val c = cur
            if (c != null && s.startMs - c.endMs < MAX_GAP_MS &&
                words + w <= MAX_WORDS_PER_PART && s.endMs - c.startMs <= MAX_PART_MS
            ) {
                cur = SpeechSegment(c.text + " " + text, c.startMs, maxOf(c.endMs, s.endMs))
                words += w
            } else {
                if (c != null) out.add(c)
                cur = SpeechSegment(text, s.startMs, s.endMs)
                words = w
            }
        }
        cur?.let { out.add(it) }
        return out
    }

    suspend fun dub(
        context: Context,
        video: File,
        segments: List<SpeechSegment>,
        lang: String,
        speechRate: Float,
        originalVolume: Float,
        onProgress: (percent: Int, stage: String) -> Unit
    ): Result<File> {
        val app = context.applicationContext
        val ts = System.currentTimeMillis()
        val parts = mergeForDubbing(segments)
        if (parts.isEmpty()) return Result.failure(Exception("لا يوجد نص للدبلجة"))

        var tts: TextToSpeech? = null
        val timelineFile = File(app.cacheDir, "dub_$ts.pcm")
        return try {
            onProgress(0, "تهيئة الصوت")
            val engine = withContext(Dispatchers.Main) { initTts(app, lang, speechRate) }
            tts = engine

            val durationMs = FFmpegHelper.durationMs(video)
            if (durationMs <= 0) throw Exception("تعذّر قراءة مدة الفيديو")

            var generated = 0
            PcmTimeline(timelineFile, SAMPLE_RATE, durationMs + 1000).use { timeline ->
                for ((i, seg) in parts.withIndex()) {
                    coroutineContext.ensureActive()
                    onProgress(i * 80 / parts.size, "توليد الصوت ${i + 1}/${parts.size}")

                    val wav = File(app.cacheDir, "tts_${ts}_$i.wav")
                    val pcm = File(app.cacheDir, "tts_${ts}_$i.pcm")
                    val fast = File(app.cacheDir, "tts_${ts}_$i.fast.pcm")
                    try {
                        if (!synth(engine, seg.text, wav, "u$i") || !wav.exists() || wav.length() < 100) continue
                        if (!FFmpegHelper.toPcm(wav, pcm, 1.0, SAMPLE_RATE)) continue

                        var finalPcm = pcm
                        val lenMs = pcm.length() * 1000 / (SAMPLE_RATE * 2)
                        val next = parts.getOrNull(i + 1)
                        val own = seg.endMs - seg.startMs
                        val slot = if (next != null) next.startMs - seg.startMs - 60 else own + 1500
                        val allowed = maxOf(slot, own, 500L)
                        // إن كان الصوت أطول من الوقت المتاح نسرّعه (حتى 1.7x) بدون تغيير طبقة الصوت
                        if (lenMs > allowed * 1.03) {
                            val factor = minOf(lenMs.toDouble() / allowed, MAX_SPEEDUP)
                            if (FFmpegHelper.toPcm(wav, fast, factor, SAMPLE_RATE)) finalPcm = fast
                        }
                        timeline.mix(finalPcm, seg.startMs)
                        generated++
                    } finally {
                        wav.delete(); pcm.delete(); fast.delete()
                    }
                }
            }
            if (generated == 0) throw Exception("فشل توليد الصوت. تحقق من صوت اللغة في إعدادات النظام.")

            FFmpegHelper.mixDubbedAudio(app, video, timelineFile, SAMPLE_RATE, originalVolume) {
                onProgress(80 + it / 5, "دمج الصوت مع الفيديو")
            }
        } catch (e: CancellationException) {
            throw e
        } catch (e: Throwable) {
            Result.failure(e)
        } finally {
            runCatching { tts?.stop(); tts?.shutdown() }
            runCatching { timelineFile.delete() }
        }
    }

    // ------------------------------------------------------------------

    private suspend fun initTts(context: Context, lang: String, rate: Float): TextToSpeech =
        suspendCancellableCoroutine { cont ->
            var created: TextToSpeech? = null
            created = TextToSpeech(context) { status ->
                val t = created
                if (status != TextToSpeech.SUCCESS || t == null) {
                    if (cont.isActive) cont.resumeWithException(Exception("محرك تحويل النص إلى كلام غير متاح على هذا الهاتف"))
                    return@TextToSpeech
                }
                val locale = Locale.forLanguageTag(lang)
                if (t.isLanguageAvailable(locale) < TextToSpeech.LANG_AVAILABLE) {
                    t.shutdown()
                    if (cont.isActive) cont.resumeWithException(TtsLanguageMissingException(lang))
                    return@TextToSpeech
                }
                t.language = locale
                t.setSpeechRate(rate.coerceIn(0.5f, 2.0f))
                if (cont.isActive) cont.resume(t)
            }
            cont.invokeOnCancellation { runCatching { created?.shutdown() } }
        }

    private suspend fun synth(tts: TextToSpeech, text: String, out: File, id: String): Boolean =
        suspendCancellableCoroutine { cont ->
            tts.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                override fun onStart(utteranceId: String?) {}
                override fun onDone(utteranceId: String?) {
                    if (utteranceId == id && cont.isActive) cont.resume(true)
                }
                @Deprecated("Deprecated in Java")
                override fun onError(utteranceId: String?) {
                    if (utteranceId == id && cont.isActive) cont.resume(false)
                }
                override fun onError(utteranceId: String?, errorCode: Int) {
                    if (utteranceId == id && cont.isActive) cont.resume(false)
                }
            })
            val r = tts.synthesizeToFile(text, Bundle(), out, id)
            if (r != TextToSpeech.SUCCESS && cont.isActive) cont.resume(false)
            cont.invokeOnCancellation { runCatching { tts.stop() } }
        }
}

/** مسار صوت PCM s16le mono بطول الفيديو؛ كل مقطع يُمزج عند وقت بدايته (مع قص الفائض) */
private class PcmTimeline(file: File, private val rate: Int, totalMs: Long) : Closeable {
    private val raf = RandomAccessFile(file, "rw")
    private val totalBytes: Long = totalMs * rate / 1000 * 2

    init { raf.setLength(totalBytes) }

    fun mix(pcm: File, startMs: Long) {
        val data = pcm.readBytes()
        val off = (startMs * rate / 1000) * 2
        var len = minOf(data.size.toLong(), totalBytes - off).toInt()
        len -= len % 2
        if (len <= 0) return
        val cur = ByteArray(len)
        raf.seek(off); raf.readFully(cur)
        var i = 0
        while (i < len) {
            val a = (cur[i + 1].toInt() shl 8) or (cur[i].toInt() and 0xFF)
            val b = (data[i + 1].toInt() shl 8) or (data[i].toInt() and 0xFF)
            val s = (a + b).coerceIn(-32768, 32767)
            cur[i] = (s and 0xFF).toByte()
            cur[i + 1] = ((s shr 8) and 0xFF).toByte()
            i += 2
        }
        raf.seek(off); raf.write(cur)
    }

    override fun close() { raf.close() }
}

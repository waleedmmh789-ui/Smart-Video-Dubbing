package com.subgenius.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.subgenius.app.ui.components.TopBar
import com.subgenius.app.ui.theme.BgDark
import com.subgenius.app.ui.theme.TextGray
import com.subgenius.app.ui.theme.TextWhite

private val sections = listOf(
    "ما الذي يعالجه التطبيق؟" to
        "الفيديوهات التي تختارها بنفسك. تُنسخ مؤقتاً داخل التطبيق لاستخراج الصوت وتحويله إلى نص (Vosk أو Whisper) ودبلجته وحرق الترجمة، " +
        "وكل ذلك يتم على هاتفك. لا نرفع فيديوهاتك ولا صوتك إلى أي خادم، ولا نملك خوادم أصلاً.",
    "الإنترنت" to
        "يُستخدم لتنزيل نماذج التعرف على الكلام (من alphacephei.com وhuggingface.co) ونماذج الترجمة دون إنترنت (Google ML Kit). " +
        "وإن اخترت «الترجمة أونلاين مجاناً» يُرسل النص المستخرج فقط (دون الفيديو أو الصوت) إلى خدمتَي Lingva (Google Translate) وMyMemory. " +
        "لتجنب إرسال أي نص اختر «بدون إنترنت (ML Kit)». الدبلجة تستعمل محرك تحويل النص إلى كلام في هاتفك، وقد يستخدم الإنترنت حسب إعداداته.",
    "ما نخزّنه" to
        "قائمة «مشاريعي» محفوظة محلياً على الهاتف فقط: اسم المشروع واللغتان وحالته ومسار الفيديو الناتج. " +
        "الفيديوهات الناتجة تُحفظ في المعرض (Movies/SubGenius) وهي ملكك، وتُحذف الملفات المؤقتة تلقائياً.",
    "ما لا نفعله" to
        "لا حسابات، ولا إعلانات، ولا تحليلات، ولا تتبع، ولا بيع أو مشاركة لأي بيانات، ولا نطلب إذن الكاميرا أو الميكروفون أو الموقع أو جهات الاتصال. للتواصل: waleedmmh789@gmail.com",
    "الأذونات" to
        "الإنترنت وحالة الشبكة للتنزيل. وعلى أندرويد 8 و9 فقط إذن الكتابة في التخزين لحفظ الفيديو في المعرض.",
    "حقوق المحتوى" to
        "أنت المسؤول عن امتلاك حق ترجمة ودبلجة الفيديوهات التي تعالجها.",
    "حذف بياناتك" to
        "احذف المشاريع من شاشة «مشاريعي»، أو امسح بيانات التطبيق من إعدادات الهاتف، أو احذف التطبيق لإزالة كل شيء."
)

@Composable
fun PrivacyScreen(onBack: () -> Unit) {
    Column(Modifier.fillMaxSize().background(BgDark).padding(horizontal = 20.dp).verticalScroll(rememberScrollState())) {
        TopBar("سياسة الخصوصية", onBack)
        Text("آخر تحديث: 20 نوفمبر 2026", color = TextGray, fontSize = 12.sp)
        sections.forEach { (title, body) ->
            Spacer(Modifier.height(16.dp))
            Text(title, color = TextWhite, fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.height(4.dp))
            Text(body, color = TextGray, fontSize = 14.sp)
        }
        Spacer(Modifier.height(32.dp))
    }
}

package com.subgenius.app.ui.screens

import android.content.Intent
import android.net.Uri
import android.speech.tts.TextToSpeech
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.subgenius.app.data.model.Project
import com.subgenius.app.data.repository.ProjectRepository
import com.subgenius.app.engine.DubbingProcessor
import com.subgenius.app.engine.FFmpegHelper
import com.subgenius.app.engine.MediaSaver
import com.subgenius.app.engine.SubtitleBuilder
import com.subgenius.app.engine.SubtitleStyle
import com.subgenius.app.engine.TtsLanguageMissingException
import com.subgenius.app.ui.AppViewModel
import com.subgenius.app.ui.components.TopBar
import com.subgenius.app.ui.components.rememberStorageGate
import com.subgenius.app.ui.theme.BgDark
import com.subgenius.app.ui.theme.ErrRed
import com.subgenius.app.ui.theme.OkGreen
import com.subgenius.app.ui.theme.Primary
import com.subgenius.app.ui.theme.Secondary
import com.subgenius.app.ui.theme.TextGray
import com.subgenius.app.ui.theme.TextWhite
import com.subgenius.app.ui.theme.WarnYellow
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun DubbingScreen(appViewModel: AppViewModel, onBack: () -> Unit, onTranslate: () -> Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val gate = rememberStorageGate()
    val state by appViewModel.state.collectAsState()
    // النص المترجم، أو (عند ترجمة Whisper المباشرة) النص الإنجليزي المستخرج نفسه
    val dubSegments = state.translatedSegments.ifEmpty {
        if (state.sourceLang != state.audioLang) state.originalSegments else emptyList()
    }
    val dubLang = if (state.translatedSegments.isNotEmpty()) state.targetLang else state.sourceLang

    var speechRate by remember { mutableFloatStateOf(1.0f) }
    var origVolume by remember { mutableFloatStateOf(0.15f) }
    var burnSubs by remember { mutableStateOf(false) }
    var working by remember { mutableStateOf(false) }
    var progress by remember { mutableIntStateOf(0) }
    var stage by remember { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }
    var voiceMissing by remember { mutableStateOf(false) }
    var savedUri by remember { mutableStateOf<Uri?>(null) }

    val hasTranslation = dubSegments.isNotEmpty()

    fun start() {
        scope.launch {
            working = true; error = null; voiceMissing = false; savedUri = null; progress = 0; stage = ""
            val video = state.videoFile
            if (video == null || dubSegments.isEmpty()) {
                error = "لا يوجد نص مترجم. ارجع واترجم النص أولاً."; working = false; return@launch
            }
            val dubbed = DubbingProcessor.dub(
                context, video, dubSegments, dubLang, speechRate, origVolume
            ) { p, s -> progress = p; stage = s }
            var out = dubbed.getOrElse { e ->
                if (e is TtsLanguageMissingException) voiceMissing = true
                error = e.message ?: "فشلت الدبلجة"; working = false; return@launch
            }

            if (burnSubs) {
                stage = "حرق الترجمة"; progress = 0
                val font = FFmpegHelper.subtitleFontFor(context, dubLang)
                val ass = SubtitleBuilder.buildAss(context, dubSegments, SubtitleStyle(fontName = font))
                    .getOrElse { out.delete(); error = it.message; working = false; return@launch }
                val burnedResult = FFmpegHelper.burnSubtitles(context, out, ass) { progress = it }
                ass.delete()
                val burned = burnedResult.getOrElse { out.delete(); error = it.message; working = false; return@launch }
                out.delete()
                out = burned
            }

            stage = "الحفظ في المعرض"
            val name = "SubGenius_Dub_" + SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
            val uri = withContext(Dispatchers.IO) { MediaSaver.saveToGallery(context, out, name) }
            out.delete()
            working = false
            if (uri == null) { error = "تعذّر حفظ الفيديو في المعرض"; return@launch }
            savedUri = uri
            ProjectRepository(context).insert(
                Project(
                    name = name, videoUri = state.videoUri ?: "", outputPath = uri.toString(),
                    sourceLang = state.sourceLang, targetLang = dubLang, status = "مدبلج"
                )
            )
        }
    }

    Column(Modifier.fillMaxSize().background(BgDark).padding(horizontal = 20.dp).verticalScroll(rememberScrollState())) {
        TopBar("دبلجة الفيديو", onBack)
        Spacer(Modifier.height(8.dp))

        if (!hasTranslation) {
            Text("الدبلجة تحتاج نصاً مترجماً. استخرج النص ثم ترجمه أولاً.", color = WarnYellow, fontSize = 14.sp)
            Spacer(Modifier.height(12.dp))
            Button(onClick = onTranslate, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(12.dp)) {
                Text("الذهاب إلى الترجمة")
            }
            return@Column
        }

        Text(
            "سيُنطق النص المترجم (${state.audioLang} ← ${dubLang}) بصوت الهاتف ويُوضع في توقيت الكلام الأصلي.",
            color = TextGray, fontSize = 13.sp
        )
        Spacer(Modifier.height(16.dp))

        Text("سرعة النطق: ${"%.1f".format(Locale.US, speechRate)}x", color = TextWhite, fontSize = 14.sp)
        Slider(value = speechRate, onValueChange = { speechRate = it }, valueRange = 0.7f..1.4f, enabled = !working)

        Text("مستوى الصوت الأصلي: ${(origVolume * 100).toInt()}%  (0 = كتم)", color = TextWhite, fontSize = 14.sp)
        Slider(value = origVolume, onValueChange = { origVolume = it }, valueRange = 0f..0.5f, enabled = !working)

        Row(verticalAlignment = Alignment.CenterVertically) {
            Checkbox(checked = burnSubs, onCheckedChange = { burnSubs = it }, enabled = !working)
            Text("احرق الترجمة على الفيديو أيضاً (أبطأ)", color = TextWhite, fontSize = 14.sp)
        }
        Spacer(Modifier.height(12.dp))

        Button(
            onClick = { gate { start() } },
            enabled = !working,
            modifier = Modifier.fillMaxWidth().height(56.dp),
            shape = RoundedCornerShape(16.dp),
            colors = ButtonDefaults.buttonColors(containerColor = Primary)
        ) { Text(if (working) "جارٍ العمل…" else "ابدأ الدبلجة", fontSize = 16.sp) }

        if (working) {
            Spacer(Modifier.height(12.dp))
            LinearProgressIndicator(progress = { progress / 100f }, modifier = Modifier.fillMaxWidth(), color = Primary)
            Text("$stage ($progress%)", color = TextGray, fontSize = 14.sp)
        }

        error?.let {
            Spacer(Modifier.height(8.dp))
            Text(it, color = ErrRed, fontSize = 14.sp)
        }
        if (voiceMissing) {
            Spacer(Modifier.height(8.dp))
            OutlinedButton(
                onClick = {
                    val install = Intent(TextToSpeech.Engine.ACTION_INSTALL_TTS_DATA).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    val settings = Intent("com.android.settings.TTS_SETTINGS").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    try { context.startActivity(install) } catch (e: Exception) {
                        try { context.startActivity(settings) } catch (_: Exception) {}
                    }
                },
                modifier = Modifier.fillMaxWidth()
            ) { Text("تثبيت صوت اللغة") }
        }

        savedUri?.let { u ->
            Spacer(Modifier.height(8.dp))
            Text("تمت الدبلجة والحفظ في المعرض (Movies/SubGenius) ✅", color = OkGreen, fontSize = 14.sp)
            OutlinedButton(onClick = { MediaSaver.openVideo(context, u) }, modifier = Modifier.fillMaxWidth()) {
                Text("فتح الفيديو")
            }
        }
        Spacer(Modifier.height(24.dp))
    }
}

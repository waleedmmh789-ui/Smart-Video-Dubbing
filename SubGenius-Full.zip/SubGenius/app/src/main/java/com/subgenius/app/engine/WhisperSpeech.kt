package com.subgenius.app.engine

import android.content.Context
import dev.ffmpegkit.whisper.Whisper
import dev.ffmpegkit.whisper.WhisperConfig
import dev.ffmpegkit.whisper.WhisperModel
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import java.io.File
import java.util.concurrent.atomic.AtomicInteger
import kotlin.coroutines.coroutineContext

/** التعرف على الكلام بـ Whisper (أدق مع اللهجات العربية من Vosk) */
object WhisperSpeech {
    val languages = listOf(
        "ar" to "العربية", "en" to "English", "fr" to "Français", "es" to "Español", "de" to "Deutsch",
        "tr" to "Türkçe", "ru" to "Русский", "zh" to "中文", "ja" to "日本語", "el" to "Ελληνικά"
    )

    private const val CHUNK_SEC = 90

    private val lock = Mutex()
    private var cachedPath: String? = null
    private var cachedModel: WhisperModel? = null
    private val active = AtomicInteger(0)

    private suspend fun getModel(context: Context, path: String): WhisperModel = lock.withLock {
        val cur = cachedModel
        if (cur != null && cachedPath == path) return@withLock cur
        cur?.let { runCatching { Whisper.releaseModel(it) } }
        cachedModel = null; cachedPath = null
        val m = Whisper.loadModel(context.applicationContext, path)
        cachedModel = m; cachedPath = path
        m
    }

    /** يحرّر النموذج من الذاكرة (فقط إن لم تكن هناك معالجة جارية) */
    fun releaseModel() {
        if (active.get() == 0 && lock.tryLock()) {
            try {
                cachedModel?.let { runCatching { Whisper.releaseModel(it) } }
                cachedModel = null; cachedPath = null
            } finally { lock.unlock() }
        }
    }

    /**
     * pcmFile: صوت خام s16le 16kHz mono.
     * translateToEnglish: Whisper يترجم من الصوت مباشرة إلى الإنجليزية (الأدق للهجات).
     */
    suspend fun transcribe(
        context: Context, pcmFile: File, modelPath: String, language: String,
        translateToEnglish: Boolean, onProgress: (Int) -> Unit = {}
    ): Result<List<SpeechSegment>> = withContext(Dispatchers.Default) {
        active.incrementAndGet()
        try {
            val model = getModel(context, modelPath)
            val total = pcmFile.length()
            if (total <= 0) return@withContext Result.success(emptyList())
            val ranges = PcmUtils.splitRanges(pcmFile, total, CHUNK_SEC)
            val threads = (Runtime.getRuntime().availableProcessors() / 2).coerceIn(2, 6)
            val out = mutableListOf<SpeechSegment>()

            ranges.forEachIndexed { i, (s, e) ->
                coroutineContext.ensureActive()
                if (!PcmUtils.isSilent(pcmFile, s, e)) {
                    val wav = File(context.cacheDir, "chunk_${System.currentTimeMillis()}_$i.wav")
                    try {
                        PcmUtils.writeWav(pcmFile, s, e, wav)
                        val r = Whisper.transcribe(
                            model, wav.absolutePath,
                            WhisperConfig(language = language, translate = translateToEnglish, threads = threads)
                        )
                        val offset = s * 1000 / PcmUtils.BYTES_PER_SEC
                        r.segments.forEach { seg ->
                            val t = seg.text.trim()
                            if (t.isNotEmpty()) out.add(SpeechSegment(t, offset + seg.startMs, offset + maxOf(seg.endMs, seg.startMs + 500)))
                        }
                    } finally { runCatching { wav.delete() } }
                }
                onProgress((((i + 1) * 100) / ranges.size).coerceIn(0, 99))
            }
            onProgress(100)
            Result.success(dedupe(out))
        } catch (e: CancellationException) {
            throw e
        } catch (e: Throwable) {
            Result.failure(e)
        } finally {
            active.decrementAndGet()
        }
    }

    /** يحذف التكرار المتتالي (علامة هلوسة شائعة في Whisper) */
    private fun dedupe(list: List<SpeechSegment>): List<SpeechSegment> {
        val out = mutableListOf<SpeechSegment>()
        for (s in list) {
            val n = out.size
            if (n >= 2 && out[n - 1].text == s.text && out[n - 2].text == s.text) continue
            out.add(s)
        }
        return out
    }
}

# عبقري الترجمة والدبلجة (SubGenius)

تطبيق أندرويد (Kotlin + Jetpack Compose): استخراج الكلام من الفيديو (**Whisper** للهجات أو **Vosk** الأسرع) ← ترجمته (أونلاين مجاني أو دون إنترنت بـ ML Kit) ← **دبلجته بصوت** و/أو حرق الترجمة ← حفظه في المعرض.

- minSdk 26 (أندرويد 8) — targetSdk 35 — معمار arm64-v8a
- اسم الحزمة: `com.subgenius.app` (غيّره قبل أول نشر: `bash scripts/rename_package.sh com.اسمك.subgenius`)

## البناء على GitHub (APK + AAB)
1. ضع محتوى هذا المجلد في **جذر** المستودع (يجب أن يظهر `app/` و`build.gradle.kts` و`.github/` مباشرة).
2. Actions ← **Build SubGenius** ← Run workflow (أو ادفع إلى `main`).
3. من Artifacts ← **SubGenius-builds**: `SubGenius-debug.apk` و`SubGenius-release.apk` و`SubGenius-release.aab`.
4. لإصدار على Releases: ادفع وسماً مثل `v1.2.0`.
> احذف أي workflow قديم من `.github/workflows` حتى لا يعمل معه.

### التوقيع
- بدون Secrets: يولّد الـ workflow مفتاحاً مؤقتاً (للتثبيت المباشر فقط، لا ترفعه إلى Google Play).
- للنشر: أنشئ مفتاحاً ثابتاً مرة واحدة (`keytool -genkeypair -v -keystore release.keystore -alias subgenius -keyalg RSA -keysize 2048 -validity 10000`) ثم `base64 -w0 release.keystore`، وأضف في GitHub Secrets: `KEYSTORE_BASE64` و`KEYSTORE_PASSWORD` و`KEY_ALIAS` و`KEY_PASSWORD`. احفظ المفتاح في مكان آمن.

## الدبلجة
تحتاج نصاً مترجماً (أو نصاً إنجليزياً من ترجمة Whisper المباشرة). تنطقه بصوت الهاتف في توقيت الكلام الأصلي. لازم يكون صوت اللغة الهدف مثبّتاً في إعدادات «تحويل النص إلى كلام» (يوجد زر لتثبيته).

## قبل النشر في Google Play
1. غيّر اسم الحزمة قبل أول رفع (لا يمكن تغييره لاحقاً).
2. فعّل **GitHub Pages** (Settings ← Pages ← مجلد `/docs`) واستعمل رابط `.../privacy-policy.html` كسياسة الخصوصية.
3. صفحات 16KB: خطوة «Check 16KB» في الـ workflow تطبع النتيجة؛ أي `FAIL` يعني مكتبة سترفضها Play (راجع `whisper-android`).
4. FFmpeg وWhisper يعملان على arm64 فقط (كل الهواتف الحديثة).
5. نموذج Whisper Small ~466MB والعربي في Vosk ~320MB؛ قد يتعثران على الهواتف الضعيفة.
6. تحقق من روابط النماذج في `WhisperModelDownloader.kt` و`VoskModelDownloader.kt` إن ظهر HTTP 404.
7. إن لم تُحمَّل `whisper-android:1.0.0` جرّب `0.1.2`.
8. الخط العربي: خط النظام، والاحتياطي المضمّن `DejaVuSans.ttf` في `assets/fonts`.

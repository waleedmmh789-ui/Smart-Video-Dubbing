package com.yourname.subgenius.engine

import android.content.Context
import android.speech.tts.TextToSpeech
import java.util.Locale

object TextToSpeechHelper {
    private var tts: TextToSpeech? = null

    fun speak(context: Context, text: String, lang: String) {
        tts?.shutdown()
        tts = TextToSpeech(context.applicationContext) { status ->
            if (status == TextToSpeech.SUCCESS) {
                tts?.language = Locale.forLanguageTag(lang)
                tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "subgenius_tts")
            }
        }
    }

    fun shutdown() { tts?.shutdown(); tts = null }
}

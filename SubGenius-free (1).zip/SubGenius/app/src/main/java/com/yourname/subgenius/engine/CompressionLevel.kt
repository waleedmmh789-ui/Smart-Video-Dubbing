package com.yourname.subgenius.engine

/**
 * q: جودة mpeg4 البرمجي (الأقل = أفضل). maxWidth: أقصى عرض (0 = بدون تصغير).
 * hwBitrate: معدل البت للترميز العتادي h264_mediacodec.
 */
enum class CompressionLevel(val q: Int, val maxWidth: Int, val hwBitrate: Int, val label: String) {
    LIGHT(3, 0, 6_000_000, "خفيف - جودة عالية"),
    MEDIUM(5, 1280, 3_000_000, "متوسط - جودة جيدة"),
    STRONG(8, 854, 1_500_000, "قوي - جودة مقبولة"),
    NONE(0, 0, 0, "بدون ضغط")
}

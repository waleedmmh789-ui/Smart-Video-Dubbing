package com.yourname.subgenius.engine

import android.content.Context
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.util.concurrent.atomic.AtomicInteger

/**
 * ترجمة أونلاين مجانية بلا مفتاح:
 *  1) Lingva (مشروع مفتوح المصدر يمرّر عبر Google Translate) — خادم افتراضي + خادم مخصص اختياري
 *  2) MyMemory (حد مجاني يومي للمستخدم المجهول ~5000 حرف)
 * ملاحظة: النص المترجَم يُرسل إلى خوادم خارجية. الخوادم العامة قد تتوقف أو تُحدّ في أي وقت.
 */
object OnlineTranslator {
    private const val DEFAULT_LINGVA = "https://lingva.ml"
    private const val PREFS = "online_translator"
    private const val KEY_LINGVA = "lingva_url"

    @Volatile private var lingvaDownUntil = 0L
    @Volatile private var myMemoryDownUntil = 0L

    fun getCustomLingva(context: Context): String =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY_LINGVA, "") ?: ""

    fun setCustomLingva(context: Context, url: String) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(KEY_LINGVA, url.trim()).apply()
        lingvaDownUntil = 0L
    }

    private fun instances(context: Context): List<String> {
        val custom = getCustomLingva(context).trim().trimEnd('/')
        return listOfNotNull(custom.takeIf { it.startsWith("https://") }) + DEFAULT_LINGVA
    }

    suspend fun translateSegments(
        context: Context, source: String, target: String,
        segments: List<SpeechSegment>, onProgress: (Int) -> Unit = {}
    ): Result<List<SpeechSegment>> = withContext(Dispatchers.IO) {
        try {
            if (segments.isEmpty()) return@withContext Result.success(emptyList())
            val hosts = instances(context)
            val done = AtomicInteger(0)
            val gate = Semaphore(4)
            val out = coroutineScope {
                segments.map { seg ->
                    async {
                        gate.withPermit {
                            val t = translateOne(seg.text, source, target, hosts)
                            onProgress((done.incrementAndGet() * 100) / segments.size)
                            SpeechSegment(t, seg.startMs, seg.endMs)
                        }
                    }
                }.awaitAll()
            }
            Result.success(out)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Throwable) {
            Result.failure(e)
        }
    }

    private fun translateOne(text: String, source: String, target: String, hosts: List<String>): String {
        val now = System.currentTimeMillis()
        if (now >= lingvaDownUntil) {
            for (h in hosts) {
                try { return lingva(h, text, source, target) } catch (_: Exception) {}
            }
            lingvaDownUntil = System.currentTimeMillis() + 60_000   // نتجاوزه دقيقة بعد فشل كل الخوادم
        }
        if (System.currentTimeMillis() >= myMemoryDownUntil) {
            try { return myMemory(text, source, target) } catch (_: Exception) {
                myMemoryDownUntil = System.currentTimeMillis() + 60_000
            }
        }
        throw Exception("تعذّرت الترجمة أونلاين (الخوادم المجانية غير متاحة أو بلغت حدها)")
    }

    private fun get(url: String): String {
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 8000; c.readTimeout = 12000
        c.setRequestProperty("User-Agent", "SubGenius/1.0")
        try {
            if (c.responseCode != 200) throw Exception("HTTP ${c.responseCode}")
            return c.inputStream.bufferedReader().use { it.readText() }
        } finally { c.disconnect() }
    }

    private fun enc(s: String) = URLEncoder.encode(s, "UTF-8").replace("+", "%20")

    private fun lingva(host: String, text: String, source: String, target: String): String {
        val body = get("$host/api/v1/$source/$target/${enc(text)}")
        val t = JSONObject(body).optString("translation", "").trim()
        if (t.isEmpty()) throw Exception("empty")
        return t
    }

    private fun mm(code: String) = if (code == "zh") "zh-CN" else code

    private fun myMemory(text: String, source: String, target: String): String {
        val q = if (text.length > 480) text.take(480) else text
        val body = get("https://api.mymemory.translated.net/get?q=${enc(q)}&langpair=${mm(source)}%7C${mm(target)}")
        val obj = JSONObject(body)
        if (obj.optInt("responseStatus", 200) != 200) throw Exception("quota")
        val t = obj.optJSONObject("responseData")?.optString("translatedText", "")?.trim().orEmpty()
        if (t.isEmpty() || t.startsWith("MYMEMORY WARNING", ignoreCase = true)) throw Exception("quota")
        return t
    }
}

package com.yourname.subgenius.ui.theme

import androidx.compose.ui.graphics.Color

val Primary = Color(0xFF6C5CE7)
val Secondary = Color(0xFF00CEC9)
val BgDark = Color(0xFF0F0F1E)
val SurfaceDark = Color(0xFF1A1A2E)
val TextWhite = Color(0xFFFFFFFF)
val TextGray = Color(0xFFB0B0B0)
val OkGreen = Color(0xFF00B894)
val ErrRed = Color(0xFFE17055)
val WarnYellow = Color(0xFFFDCB6E)

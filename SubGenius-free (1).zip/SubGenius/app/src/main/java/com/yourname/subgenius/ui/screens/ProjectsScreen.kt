package com.yourname.subgenius.ui.screens

import android.net.Uri
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Movie
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.yourname.subgenius.data.repository.ProjectRepository
import com.yourname.subgenius.engine.MediaSaver
import com.yourname.subgenius.ui.components.TopBar
import com.yourname.subgenius.ui.theme.BgDark
import com.yourname.subgenius.ui.theme.ErrRed
import com.yourname.subgenius.ui.theme.Primary
import com.yourname.subgenius.ui.theme.SurfaceDark
import com.yourname.subgenius.ui.theme.TextGray
import com.yourname.subgenius.ui.theme.TextWhite
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ProjectsScreen(onBack: () -> Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val repo = remember { ProjectRepository(context) }
    val projects by repo.getAll().collectAsState(initial = emptyList())

    Column(Modifier.fillMaxSize().background(BgDark).padding(horizontal = 20.dp)) {
        TopBar("مشاريعي", onBack)
        if (projects.isEmpty()) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { Text("لا توجد مشاريع بعد", color = TextGray) }
        } else {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(projects, key = { it.id }) { p ->
                    Card(
                        onClick = { p.outputPath?.let { MediaSaver.openVideo(context, Uri.parse(it)) } },
                        modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(12.dp),
                        colors = CardDefaults.cardColors(containerColor = SurfaceDark)
                    ) {
                        Row(Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Filled.Movie, null, tint = Primary, modifier = Modifier.size(32.dp))
                            Spacer(Modifier.width(12.dp))
                            Column(Modifier.weight(1f)) {
                                Text(p.name, color = TextWhite, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
                                Text("${p.sourceLang} → ${p.targetLang} • ${p.status}", color = TextGray, fontSize = 12.sp)
                            }
                            IconButton(onClick = { scope.launch { repo.delete(p) } }) {
                                Icon(Icons.Filled.Delete, contentDescription = "حذف", tint = ErrRed)
                            }
                        }
                    }
                }
            }
        }
    }
}
